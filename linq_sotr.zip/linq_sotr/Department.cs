﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace linq_sotr
{
    class Department
    {
        public string Name { get; set; }
        public string Reg { get; set; }
    }
}
