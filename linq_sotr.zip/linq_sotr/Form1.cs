﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace linq_sotr
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            List<Department> department = new List<Department>()
            {
                new Department { Name = "Отдел закупок", Reg ="Германия" },
                new Department { Name = "Отдел продаж", Reg ="Испания" },
                new Department { Name = "Отдел маркетинга", Reg ="Испания" }
            };
            List<Employ> employ = new List<Employ>()
            {
                new Employ {Name="Иванов", department = "Отдел закупок"},
                new Employ {Name="Петров", department ="Отдел закупок"},
                new Employ {Name="Сидоров", department = "Отдел продаж "},
                new Employ {Name="Лямин", department = "Отдел продаж"},
                new Employ {Name="Сидоренко", department = "Отдел маркетинга"},
                new Employ {Name="Кривоносов", department = "Отдел продаж"}
            };
            var result = from emp in employ
                          join d in department on emp.department equals d.Name
                          select new { Name_ = emp.Name, Departments = emp.department, Region = d.Reg };
            label1.Text += "\n\n";
            foreach (var a in result)
                label1.Text += ($"{a.Name_} - {a.Departments} ({a.Region})\n");
            var result2 = from dep in department
                          join emp in employ on dep.Name equals emp.department
                          where dep.Reg.StartsWith("И")
                          select emp.Name;
            label2.Text += "\n\n";
            foreach (var b in result2)
                label2.Text += $"{b}\n";
        }
    }
}
