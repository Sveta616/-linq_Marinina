﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace linq
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            List<Person> people = new List<Person>();
            string file = "file.txt";
            if (!File.Exists(file))
            {
                MessageBox.Show("Файл не найден");
            }
            else
            {
                label1.Text += $"\n\n";
                string[] lines = File.ReadAllLines(file);
                Person p = new Person("", "", "", 0, 0);
                foreach (string line in lines)
                {

                    string[] pep = line.Split(' ');
                    string surname = pep[0];
                    p.set_surname(surname);
                    string name = pep[1];
                    p.set_name(name);
                    string ot = pep[2];
                    p.set_ot(ot);
                    int age = Convert.ToInt32(pep[3]);
                    p.set_age(age);
                    double weidth = Convert.ToDouble(pep[4]);
                    p.set_weidth(weidth);
                    label1.Text += $"{p.get_surname()} {p.get_name()} {p.get_ot()} {p.get_age()} {p.get_weidth()}\n";
                    people.Add(new Person(surname, name, ot, age, weidth));
                }

                var young = from c in people
                            where Convert.ToInt32(p.get_age()) < 40
                            select c;
                label2.Text += $"\n\n";
                foreach (var a in young)
                {
                    label2.Text += $"ФИО: {a.get_surname()} {a.get_name()} {a.get_ot()}\nВозраст: {a.get_age()}\nВес: {a.get_weidth()}\n\n\n";
                }


            }
        }
    }     
}
