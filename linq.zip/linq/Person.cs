﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace linq
{
   
        class Person
        {
            private string surname;
            private string name;
            private string ot;
            private int age;
            private double weidth;

            public Person(string surname, string name, string ot, int age, double weidth)
            {
                this.surname = surname;
                this.name = name;
                this.ot = ot;
                this.age = age;
                this.weidth = weidth;
            }
            public void set_surname(string n)
            {
                this.surname = n;
            }
            public string get_surname()
            {
                return surname;
            }
            public void set_name(string n)
            {
                this.name = n;
            }
            public string get_name()
            {
                return this.name;
            }
            public void set_ot(string n)
            {
                this.ot = n;
            }
            public string get_ot()
            {
                return this.ot;
            }
            public void set_age(int n)
            {
                this.age = n;
            }
            public int get_age()
            {
                return this.age;
            }
            public void set_weidth(double n)
            {
                this.weidth = n;
            }
            public double get_weidth()
            {
                return this.weidth;
            }

        }
    }



