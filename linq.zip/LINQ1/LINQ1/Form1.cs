﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace LINQ1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            List<People> people = new List<People>();
            string file = "file.txt";
            if (!File.Exists(file))
            {
                MessageBox.Show("Файл не найден");
            }
            else
            {
                string[] a = File.ReadAllLines(file);
                People pp = new People("", "", "", 0, 0);
                foreach (string b in a)
                {

                    string[] chelovek = b.Split(' ');
                    string name = chelovek[0];
                    pp.Set_Name(name);
                    string surname = chelovek[1];
                    pp.Set_Surname(surname);
                    string ot = chelovek[2];
                    pp.Set_Ot(ot);
                    int voz = Convert.ToInt32(chelovek[3]);
                    pp.Set_Voz(voz);
                    double ves = Convert.ToDouble(chelovek[4]);
                    pp.Set_Ves(ves);
                    label3.Text += ($"{pp.Get_Name()} {pp.Get_Surname()} {pp.Get_Ot()} {pp.Get_Voz()} {pp.Get_Ves()} \n");
                    people.Add(new People(name, surname,ot, voz, ves));
                    
                }
                var pep = from p in people
                where Convert.ToInt32(p.Get_Voz()) < 40
                select p;
                foreach (var a1 in pep)
                {
                    label4.Text += ($"Имя: {a1.Get_Name()} \nФамилия: {a1.Get_Surname()} \nОтчество: {a1.Get_Ot()}\nВозраст: {a1.Get_Voz()}\nВес: {a1.Get_Ves()}\n");
                }
            }
        }
    }
}
